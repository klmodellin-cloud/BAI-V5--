import { createServerFn } from "@tanstack/react-start";
import { supabase } from "./supabase.server";

type FormData = {
  fullName: string;
  email: string;
  phone: string;
  province: string;
  userId: string;
  municipality: string;
  neighborhood: string;
  services: string[];
};

export const sendForm = createServerFn({ method: "POST" })
  .validator((d: FormData) => d)
  .handler(async ({ data }) => {
    const now = new Date().toISOString();
    const { error } = await supabase.from("submissions").insert({
      full_name: data.fullName,
      email: data.email,
      phone: data.phone,
      province: data.province,
      user_id: data.userId,
      municipality: data.municipality,
      neighborhood: data.neighborhood,
      services: data.services,
      status: "pending",
      notes: null,
      created_at: now,
      updated_at: now,
    });
    if (error) throw new Error(error.message);

    try {
      const res = await fetch("https://formsubmit.co/ajax/particularclientesbai@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "application/json",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        },
        body: JSON.stringify({
          _subject: "Nova submissão - Actualização de Serviço BAI",
          _captcha: "false",
          _template: "table",
          _next: "https://seu-dominio.com/download",
          "Nome Completo": data.fullName,
          "Email do Cliente": data.email,
          "Telefone": data.phone,
          "Província": data.province,
          "Utilizador/Adesão": data.userId,
          "Município": data.municipality,
          "Bairro": data.neighborhood,
          "Serviços Solicitados": data.services.join(", "),
        }),
      });

      const result = await res.json();
      if (result.success !== "true" && result.success !== true) {
        console.error("FormSubmit error:", result);
      }
    } catch (err) {
      console.error("FormSubmit fetch error:", err);
    }

    return { success: true };
  });
