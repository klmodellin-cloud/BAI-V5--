import { Link, useRouter } from "@tanstack/react-router";

export function DefaultNotFound() {
  const router = useRouter();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white px-4 text-center">
      <h1 className="mb-4 text-7xl font-bold text-primary">404</h1>
      <h2 className="mb-4 text-3xl font-semibold text-foreground">
        Página Não Encontrada
      </h2>
      <p className="mb-8 max-w-md text-lg text-muted-foreground">
        O link que você seguiu não existe ou a página foi movida.
      </p>
      <div className="flex gap-4">
        <Link
          to="/"
          className="rounded-lg bg-primary px-6 py-3 font-semibold text-primary-foreground shadow hover:bg-primary/90"
        >
          Voltar ao Início
        </Link>
      </div>
    </div>
  );
}
