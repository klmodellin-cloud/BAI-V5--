import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/download")({
  head: () => ({
    meta: [
      { title: "Fale Connosco | Portal do Cliente BAI" },
      {
        name: "description",
        content:
          "Entre em contacto connosco via WhatsApp para concluir a actualização do serviço.",
      },
    ],
  }),
  component: DownloadPage,
});

const BAI_LOGO_URL =
  "https://play-lh.googleusercontent.com/St5gd2375PoOOWTaDHS4A0S9M1xu8U40VBtTiswPugBE2d6vTKAxFr0ltz2PBb8UAc_cps360UAKdWooVGua";
const WHATSAPP_NUMBER = "244923004455";
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Olá! Preciso de ajuda com a actualização do serviço BAI.")}`;

function DownloadPage() {
  return (
    <main className="min-h-screen bg-background text-foreground pb-[env(safe-area-inset-bottom)]">
      <div
        className="w-full py-8 sm:py-12 px-4 sm:px-6"
        style={{ background: "var(--gradient-bai)" }}
      >
        <img
          src={BAI_LOGO_URL}
          alt="BAI"
          className="mx-auto h-20 sm:h-28 w-auto object-contain"
        />
      </div>
      <div className="mx-auto max-w-2xl px-4 sm:px-6 py-8 sm:py-12 text-center">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight">
          Fale Connosco
        </h1>
        <p className="mt-4 text-muted-foreground px-2">
          Para concluir o processo de actualização, entre em contacto connosco
          via WhatsApp.
        </p>

        <div className="mt-8 sm:mt-10 flex items-center justify-center">
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Falar no WhatsApp"
            className="group inline-block transition-transform duration-300 hover:scale-110 active:scale-95 animate-[pulse_2.5s_ease-in-out_infinite]"
          >
            <svg
              viewBox="0 0 32 32"
              className="h-44 w-44 sm:h-56 sm:w-56 md:h-64 md:w-64 drop-shadow-xl"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="16" cy="16" r="16" fill="#25D366" />
              <path
                d="M23.3 8.7A11.2 11.2 0 0 0 5.5 13l-1.6 5.1 5.3-1.3a9.4 9.4 0 0 0 4.7 1.2h.1a9.5 9.5 0 0 0 9.3-7.7c.2-.9.2-1.8 0-2.6zM16 23.5a9.3 9.3 0 0 1-4.8-1.3l-.3-.2-3.2.8.9-3-.2-.3A9.4 9.4 0 0 1 6.5 16a9.5 9.5 0 0 1 16-6.4 9.4 9.4 0 0 1 0 13.9z"
                fill="#fff"
              />
              <path
                d="M20.5 17.5c-.3-.1-1.6-.8-1.9-.9s-.4-.1-.6.1-.7.9-.9 1.1-.3.2-.6.1a7.5 7.5 0 0 1-2.2-1.4 8.3 8.3 0 0 1-1.5-1.8c-.2-.3 0-.5.1-.6l.5-.5.3-.5a.6.6 0 0 0 0-.5l-.9-2.1a.7.7 0 0 0-.6-.3h-.5a.9.9 0 0 0-.7.3c-.2.3-.8.8-.8 1.9s.8 2.2.9 2.4c.2.2 1.6 2.5 4 3.5a13 13 0 0 0 1.3.4 3.1 3.1 0 0 0 1.2.1 2.1 2.1 0 0 0 1.3-.9c.2-.3.2-.6.2-.8s-.2-.4-.5-.5z"
                fill="#fff"
              />
            </svg>
          </a>
        </div>
        <p className="mt-4 text-sm font-medium text-foreground">
          Toque no ícone para falar connosco no WhatsApp
        </p>

        <div className="mt-8 sm:mt-10 rounded-md border border-border bg-card p-4 text-sm text-muted-foreground">
          A nossa equipa irá ajudá-lo a finalizar a activação do serviço.
        </div>

        <div className="mt-6 sm:mt-8 pb-4">
          <Link to="/" className="text-sm text-primary hover:underline min-h-[44px] inline-flex items-center">
            ← Voltar ao início
          </Link>
        </div>
      </div>
    </main>
  );
}
