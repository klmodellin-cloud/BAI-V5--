import { Link, useRouter } from "@tanstack/react-router";

export function DefaultCatchBoundary() {
  const router = useRouter();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white px-4 text-center">
      <h1 className="mb-4 text-7xl font-bold text-destructive">Erro</h1>
      <h2 className="mb-4 text-3xl font-semibold text-foreground">
        Algo deu Errado
      </h2>
      <p className="mb-8 max-w-md text-lg text-muted-foreground">
        Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.
      </p>
      <div className="flex gap-4">
        <button
          onClick={() => router.invalidate()}
          className="rounded-lg bg-primary px-6 py-3 font-semibold text-primary-foreground shadow hover:bg-primary/90"
        >
          Tentar Novamente
        </button>
        <Link
          to="/"
          className="rounded-lg border border-border bg-white px-6 py-3 font-semibold text-foreground shadow hover:bg-muted"
        >
          Voltar ao Início
        </Link>
      </div>
    </div>
  );
}
