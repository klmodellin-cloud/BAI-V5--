import { createServerFn } from "@tanstack/react-start";
import { supabase } from "./supabase.server";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "bai2024";

export type Submission = {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  province: string;
  user_id: string;
  municipality: string;
  neighborhood: string;
  services: string[];
  status: "pending" | "contacted" | "completed" | "cancelled";
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type Service = {
  id: string;
  name: string;
  active: boolean;
  sort_order: number;
};

export const adminLogin = createServerFn({ method: "POST" })
  .validator((d: { password: string }) => d)
  .handler(async ({ data }) => {
    if (data.password !== ADMIN_PASSWORD) {
      throw new Error("Palavra-passe inválida");
    }
    return { success: true, token: Buffer.from(`admin:${Date.now()}`).toString("base64") };
  });

export const getSubmissions = createServerFn({ method: "GET" })
  .handler(async () => {
    const { data, error } = await supabase
      .from("submissions")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data || []) as Submission[];
  });

export const updateSubmissionStatus = createServerFn({ method: "POST" })
  .validator((d: { id: string; status: string; notes?: string }) => d)
  .handler(async ({ data }) => {
    const updates: Record<string, unknown> = {
      status: data.status,
      updated_at: new Date().toISOString(),
    };
    if (data.notes !== undefined) updates.notes = data.notes;

    const { error } = await supabase
      .from("submissions")
      .update(updates)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const deleteSubmission = createServerFn({ method: "POST" })
  .validator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const { error } = await supabase
      .from("submissions")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const getServices = createServerFn({ method: "GET" })
  .handler(async () => {
    const { data, error } = await supabase
      .from("services")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return (data || []) as Service[];
  });

export const addService = createServerFn({ method: "POST" })
  .validator((d: { name: string }) => d)
  .handler(async ({ data }) => {
    const { data: existing } = await supabase
      .from("services")
      .select("id")
      .eq("name", data.name)
      .maybeSingle();
    if (existing) throw new Error("Serviço já existe");

    const { data: maxOrder } = await supabase
      .from("services")
      .select("sort_order")
      .order("sort_order", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { error } = await supabase.from("services").insert({
      name: data.name,
      active: true,
      sort_order: (maxOrder?.sort_order || 0) + 1,
    });
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const toggleService = createServerFn({ method: "POST" })
  .validator((d: { id: string; active: boolean }) => d)
  .handler(async ({ data }) => {
    const { error } = await supabase
      .from("services")
      .update({ active: data.active })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const deleteService = createServerFn({ method: "POST" })
  .validator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const { error } = await supabase
      .from("services")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { success: true };
  });

export const getStats = createServerFn({ method: "GET" })
  .handler(async () => {
    const { data: subs, error: subsError } = await supabase
      .from("submissions")
      .select("status, created_at");
    if (subsError) throw new Error(subsError.message);

    const { data: services, error: svcError } = await supabase
      .from("services")
      .select("active");
    if (svcError) throw new Error(svcError.message);

    const now = new Date();
    const todayStr = now.toDateString();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const all = subs || [];
    const today = all.filter((s) => new Date(s.created_at).toDateString() === todayStr);
    const thisWeek = all.filter((s) => new Date(s.created_at) >= weekAgo);

    return {
      total: all.length,
      pending: all.filter((s) => s.status === "pending").length,
      contacted: all.filter((s) => s.status === "contacted").length,
      completed: all.filter((s) => s.status === "completed").length,
      cancelled: all.filter((s) => s.status === "cancelled").length,
      today: today.length,
      thisWeek: thisWeek.length,
      servicesTotal: services?.length || 0,
      servicesActive: services?.filter((s) => s.active).length || 0,
    };
  });

export const saveSubmission = createServerFn({ method: "POST" })
  .validator((d: {
    fullName: string;
    email: string;
    phone: string;
    province: string;
    userId: string;
    municipality: string;
    neighborhood: string;
    services: string[];
  }) => d)
  .handler(async ({ data }) => {
    const now = new Date().toISOString();
    const { error } = await supabase.from("submissions").insert({
      full_name: data.fullName,
      email: data.email,
      phone: data.phone,
      province: data.province,
      user_id: data.userId,
      municipality: data.municipality,
      neighborhood: data.neighborhood,
      services: data.services,
      status: "pending",
      notes: null,
      created_at: now,
      updated_at: now,
    });
    if (error) throw new Error(error.message);
    return { success: true };
  });
