import { createServerFn } from "@tanstack/react-start";

export const checkSandbox = createServerFn({ method: "GET" }).handler(
  async () => {
    return {
      isSandbox:
        typeof process !== "undefined" &&
        (process.env?.LOVABLE_SANDBOX === "1" || process.env?.LOVABLE_WORKER === "1"),
    };
  },
);
