declare namespace NodeJS {
  interface ProcessEnv {
    LOVABLE_WORKER: "1" | undefined;
    LOVABLE_SANDBOX: "1" | undefined;
  }
}
