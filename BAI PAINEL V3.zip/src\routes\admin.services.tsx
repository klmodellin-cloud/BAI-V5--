import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/services")({
  component: Services,
});

type Service = {
  id: string;
  name: string;
  active: boolean;
  sort_order: number;
};

function ConfirmModal({ open, title, message, confirmLabel, onConfirm, onCancel }: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onCancel}>
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
        <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
          <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
        </div>
        <h3 className="text-lg font-bold text-gray-900 text-center mb-2">{title}</h3>
        <p className="text-sm text-gray-500 text-center mb-6">{message}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 rounded-xl border-2 border-gray-200 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors">Cancelar</button>
          <button onClick={onConfirm} className="flex-1 rounded-xl py-2.5 text-sm font-semibold text-white transition-colors hover:opacity-90" style={{ backgroundColor: "#dc2626" }}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}

function Services() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [adding, setAdding] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  async function load() {
    const { getServices } = await import("@/lib/admin.server");
    const data = await getServices();
    setServices(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim() || adding) return;
    setAdding(true);
    try {
      const { addService } = await import("@/lib/admin.server");
      await addService({ data: { name: newName.trim() } });
      setNewName("");
      toast.success("Serviço adicionado com sucesso");
      load();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erro ao adicionar serviço");
    } finally {
      setAdding(false);
    }
  }

  async function toggle(id: string, active: boolean) {
    const { toggleService } = await import("@/lib/admin.server");
    await toggleService({ data: { id, active } });
    toast.success(active ? "Serviço activado" : "Serviço desactivado");
    load();
  }

  async function remove(id: string) {
    const { deleteService } = await import("@/lib/admin.server");
    await deleteService({ data: { id } });
    toast.success("Serviço eliminado com sucesso");
    setDeleteId(null);
    load();
  }

  const activeCount = services.filter((s) => s.active).length;

  if (loading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-10 w-36 rounded-xl bg-gray-100 animate-pulse" />
        <div className="h-16 rounded-2xl bg-gray-100 animate-pulse" />
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-16 rounded-2xl bg-gray-100 animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-5">
      <ConfirmModal
        open={!!deleteId}
        title="Eliminar Serviço"
        message="Tem certeza que deseja eliminar este serviço? Esta ação não pode ser desfeita."
        confirmLabel="Eliminar"
        onConfirm={() => deleteId && remove(deleteId)}
        onCancel={() => setDeleteId(null)}
      />

      <div>
        <h1 className="text-2xl font-bold text-gray-900">Serviços</h1>
        <p className="text-sm text-gray-500 mt-1">{activeCount} activos de {services.length} total</p>
      </div>

      <div className="bg-white rounded-2xl border-2 border-gray-100 p-5">
        <form onSubmit={add} className="flex gap-3">
          <div className="relative flex-1">
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Nome do novo serviço..."
              required
              className="w-full rounded-xl border-2 border-gray-200 bg-gray-50/50 pl-12 pr-4 py-3 text-sm outline-none transition-all focus:border-[#007473] focus:ring-4 focus:ring-[#007473]/10 hover:border-gray-300 placeholder:text-gray-400 min-h-[50px]"
            />
          </div>
          <button
            type="submit"
            disabled={adding || !newName.trim()}
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white rounded-xl transition-all min-h-[50px] shadow-lg hover:shadow-xl active:scale-[0.97] disabled:opacity-60 disabled:shadow-none"
            style={{ backgroundColor: "#007473" }}
          >
            {adding ? (
              <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
            )}
            Adicionar
          </button>
        </form>
      </div>

      {services.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" />
            </svg>
          </div>
          <p className="font-semibold text-gray-900">Nenhum serviço configurado</p>
          <p className="text-sm text-gray-400 mt-1">Adicione serviços para exibir no formulário público</p>
        </div>
      ) : (
        <div className="space-y-2">
          {services.map((s) => (
            <div
              key={s.id}
              className="bg-white rounded-2xl border-2 border-gray-100 px-5 py-4 flex items-center gap-4 hover:border-gray-200 hover:shadow-md transition-all duration-200"
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-sm font-bold text-white" style={{ backgroundColor: s.active ? "#007473" : "#9ca3af" }}>
                {s.sort_order}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-semibold ${s.active ? "text-gray-900" : "text-gray-400 line-through"}`}>
                  {s.name}
                </p>
                <p className="text-xs text-gray-400 mt-0.5 flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${s.active ? "bg-green-500" : "bg-gray-300"}`} />
                  {s.active ? "Activo" : "Inactivo"}
                </p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <button
                  onClick={() => toggle(s.id, !s.active)}
                  className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${
                    s.active ? "bg-green-500" : "bg-gray-200"
                  }`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-200 ${
                    s.active ? "left-[26px]" : "left-0.5"
                  }`} />
                </button>
                <button
                  onClick={() => setDeleteId(s.id)}
                  className="p-2 rounded-xl text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all"
                  title="Eliminar"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
