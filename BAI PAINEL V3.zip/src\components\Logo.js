import type { SVGProps } from "react";

export function Logo({ className, ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      className={className}
      {...props}
    >
      <rect width="100" height="100" fill="currentColor" />
      <rect y="33" width="100" height="34" fill="#ffffff" />
    </svg>
  );
}
