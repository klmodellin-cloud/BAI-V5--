import { EventRegistryClient } from "@lovable.dev/webhooks-js";

export const events = new EventRegistryClient({
  publishableKey: process.env.VITE_LOVABLE_PUBLISHABLE_KEY ?? "",
});
